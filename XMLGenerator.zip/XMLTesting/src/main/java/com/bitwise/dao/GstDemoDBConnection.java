package com.bitwise.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.bitwise.xml.parser.dto.ColumnDetails;
import com.bitwise.xml.parser.dto.JobInput;
import com.bitwise.xml.parser.dto.Table;

public class GstDemoDBConnection {

	 // init database constants
    private static final String DATABASE_DRIVER = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
    private static final String DATABASE_URL = "jdbc:sqlserver://dbdevsrv:49732" + ";instance=sql2012" + ";databaseName=GST";
    private static final String USERNAME = "gst";
    private static final String PASSWORD = "gst";
    JobInput jobInput= new JobInput();
    Table tableSource = new Table();
    Table tableTarget = new Table();
    ColumnDetails columnDetails= new ColumnDetails();
    List<ColumnDetails> columnDetailsListSource = new ArrayList<ColumnDetails>();
    List<ColumnDetails> columnDetailsListTarget = new ArrayList<ColumnDetails>();
    
    //Queries
    private static final String SELECT_QUERY_FOR_SYSTEM_DIM_AGG_TABLE ="select * from [dbo].[SYSTEM_DIM_AGG_TABLE$] where SRC_TRG_SEQ_NO = ?;";
    private static final String SELECT_QUERY_FOR_COUNT_SYSTEM_DIM_AGG_TABLE="select distinct(SRC_TRG_SEQ_NO) FROM [GST].[dbo].[SYSTEM_DIM_AGG_TABLE$];";
    
    private static final String SELECT_QUERY_FOR_FACT_TBL_DETAIL = "select * from [dbo].[FACT_TBL_DETAIL] where SEQ_COUNT = ?;";
    

    //init connection object
    private Connection connection;
    //init properties object
    private Properties properties;

    private Properties getProperties() {
        if (properties == null) {
            properties = new Properties();
            properties.setProperty("user", USERNAME);
            properties.setProperty("password", PASSWORD);
        }
        return properties;
    }

    // connect database
    public Connection getConnection() {
        if (connection == null) {
            try {
                Class.forName(DATABASE_DRIVER);
                connection = DriverManager.getConnection(DATABASE_URL, getProperties());
            } catch (ClassNotFoundException | SQLException e) {
                e.printStackTrace();
            }
        }
        return connection;
    }
    // disconnect database
    public void disconnect() {
        if (connection != null) {
            try {
                connection.close();
                connection = null;
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    public Table setSourceTableDetails(ResultSet resultSet){
    	try{
    		if(resultSet.getString("SRC_TBL_NM") != null)
    			tableSource.setTableName(resultSet.getString("SRC_TBL_NM"));
    		ColumnDetails columnDetailsSource= new ColumnDetails();
    		columnDetailsSource.setColumnName(resultSet.getString("SRC_COLUMN_NM") != null ? resultSet.getString("SRC_COLUMN_NM"):null);
    		columnDetailsSource.setSqlType(resultSet.getString("SRC_DATA_TYP")!= null ? resultSet.getString("SRC_DATA_TYP"):null);
    		columnDetailsSource.setPrecision(resultSet.getString("SRC_PRECISION") != null ? resultSet.getString("SRC_PRECISION"):null);
    		columnDetailsSource.setScale(resultSet.getString("SRC_SCALE")!= null ? resultSet.getString("SRC_SCALE"):null);
    		columnDetailsSource.setNullability(resultSet.getString("SRC_NULLABILITY") != null ? resultSet.getString("SRC_NULLABILITY"):null);
    		columnDetailsSource.setSrcChangeCapture(resultSet.getString("SRC_CHNG_CPTRE")  != null ? resultSet.getString("SRC_CHNG_CPTRE"):"Y");
    		
    		if(resultSet.getString("SRC_MAX_LENGHT") != null )
    			columnDetailsSource.setMax(resultSet.getString("SRC_MAX_LENGHT"));
    		if("Y".equalsIgnoreCase(resultSet.getString("SRC_BUSINESS_KEY"))){
    			columnDetailsSource.setKey("Y");
    			tableSource.setKeyColumn(columnDetailsSource);
    		}else{
    			columnDetailsSource.setKey("N");
    		}
    		columnDetailsListSource.add(columnDetailsSource);
    		//Setting Table details for source
        	tableSource.setColumns(columnDetailsListSource);
    	}catch(SQLException e){
        	System.out.println("Error message "+e.getMessage());
        	e.printStackTrace();
        }finally{
        }
    	return tableSource;
    }
    	
    public Table setTargetTableDetails(ResultSet resultSet){
    	try{	
    		if(resultSet.getString("TRGT_TBL_NM") != null)
        		tableTarget.setTableName(resultSet.getString("TRGT_TBL_NM"));
    		ColumnDetails columnDetailsTarget= new ColumnDetails();
        	columnDetailsTarget.setColumnName(resultSet.getString("TRGT_COLUMN_NM"));
        	columnDetailsTarget.setSqlType(resultSet.getString("TRGT_DATA_TYPE") != null ? resultSet.getString("TRGT_DATA_TYPE"):null);
        	columnDetailsTarget.setPrecision(resultSet.getString("TRGT_PRECISION") != null ? resultSet.getString("TRGT_PRECISION"):null);
        	columnDetailsTarget.setScale(resultSet.getString("TRGT_SCALE") != null ? resultSet.getString("TRGT_SCALE"):null);
        	columnDetailsTarget.setNullability(resultSet.getString("TRGT_NULLABILITY") != null ? resultSet.getString("TRGT_NULLABILITY"):null);
        	
        		if(resultSet.getString("TRGT_SURROGATE_KEY") != null  && resultSet.getString("TRGT_SURROGATE_KEY").trim().equalsIgnoreCase("Y")){
        			columnDetailsTarget.setSurrogateKey("Y");
        		}else{
        			columnDetailsTarget.setSurrogateKey("N");
        		}
        		if(resultSet.getString("TRGT_MAX_LENGHT") != null)
        			columnDetailsTarget.setMax(resultSet.getString("TRGT_MAX_LENGHT"));
        		if("Y".equalsIgnoreCase(resultSet.getString("TRGT_BUSINESS_KEY"))){
        			columnDetailsTarget.setKey("Y");
        			tableTarget.setKeyColumn(columnDetailsTarget);
        		}else{
        			columnDetailsTarget.setKey("N");
        		}
        		columnDetailsListTarget.add(columnDetailsTarget);
        	//Setting Table details for target
        	tableTarget.setColumns(columnDetailsListTarget);
        	
    	}catch(SQLException e){
        	System.out.println("Error message "+e.getMessage());
        	e.printStackTrace();
        }finally{
        	
        }
    	return tableTarget;
    }
    
    public Table setSourceDimTableDetails(ResultSet resultSet){
    	try{
    		if(resultSet.getString("SRC_TBL_NM") != null)
    			tableSource.setTableName(resultSet.getString("SRC_TBL_NM"));
    		ColumnDetails columnDetailsSource= new ColumnDetails();
    		columnDetailsSource.setColumnName(resultSet.getString("SRC_COLUMN_NM") != null ? resultSet.getString("SRC_COLUMN_NM"):null);
    		columnDetailsSource.setSqlType(resultSet.getString("SRC_COL_DATA_TYP")!= null ? resultSet.getString("SRC_COL_DATA_TYP"):null);
    		columnDetailsSource.setPrecision(resultSet.getString("SRC_PRECISION") != null ? resultSet.getString("SRC_PRECISION"):null);
    		columnDetailsSource.setScale(resultSet.getString("SRC_SCALE")!= null ? resultSet.getString("SRC_SCALE"):null);
    		columnDetailsSource.setNullability(resultSet.getString("SRC_NULLABILITY") != null ? resultSet.getString("SRC_NULLABILITY"):null);
    		columnDetailsSource.setSrcChangeCapture(resultSet.getString("SRC_CHNG_CPTRE")  != null ? resultSet.getString("SRC_CHNG_CPTRE"):"Y");
    		
    		if(resultSet.getString("SRC_COL_LENGHT") != null )
    			columnDetailsSource.setMax(resultSet.getString("SRC_COL_LENGHT"));
    		if("Y".equalsIgnoreCase(resultSet.getString("SRC_BUSINESS_KEY"))){
    			columnDetailsSource.setKey("Y");
    			tableSource.setKeyColumn(columnDetailsSource);
    		}else{
    			columnDetailsSource.setKey("N");
    		}
    		columnDetailsListSource.add(columnDetailsSource);
    		//Setting Table details for source
        	tableSource.setColumns(columnDetailsListSource);
    	}catch(SQLException e){
        	System.out.println("Error message "+e.getMessage());
        	e.printStackTrace();
        }finally{
        }
    	return tableSource;
    }
    	
    public Table setTargetFactTableDetails(ResultSet resultSet){
    	try{	
    		if(resultSet.getString("TRGT_TBL_NM") != null)
        		tableTarget.setTableName(resultSet.getString("TRGT_TBL_NM"));
    		ColumnDetails columnDetailsTarget= new ColumnDetails();
        	columnDetailsTarget.setColumnName(resultSet.getString("TRGT_COLUMN_NM"));
        	columnDetailsTarget.setSqlType(resultSet.getString("TRGT_DATA_TYPE") != null ? resultSet.getString("TRGT_DATA_TYPE"):null);
        	columnDetailsTarget.setPrecision(resultSet.getString("TRGT_PRECISION") != null ? resultSet.getString("TRGT_PRECISION"):null);
        	columnDetailsTarget.setScale(resultSet.getString("TRGT_SCALE") != null ? resultSet.getString("TRGT_SCALE"):null);
        	columnDetailsTarget.setNullability(resultSet.getString("TRGT_NULLABILITY") != null ? resultSet.getString("TRGT_NULLABILITY"):null);
        	
        		if(resultSet.getString("TRGT_SURROGATE_KEY") != null  && resultSet.getString("TRGT_SURROGATE_KEY").trim().equalsIgnoreCase("Y")){
        			columnDetailsTarget.setSurrogateKey("Y");
        		}else{
        			columnDetailsTarget.setSurrogateKey("N");
        		}
        		if(resultSet.getString("TRGT_MAX_LENGHT") != null)
        			columnDetailsTarget.setMax(resultSet.getString("TRGT_MAX_LENGHT"));
        		if("Y".equalsIgnoreCase(resultSet.getString("TRGT_BUSINESS_KEY"))){
        			columnDetailsTarget.setKey("Y");
        			tableTarget.setKeyColumn(columnDetailsTarget);
        		}else{
        			columnDetailsTarget.setKey("N");
        		}
        		columnDetailsListTarget.add(columnDetailsTarget);
        	//Setting Table details for target
        	tableTarget.setColumns(columnDetailsListTarget);
        	
    	}catch(SQLException e){
        	System.out.println("Error message "+e.getMessage());
        	e.printStackTrace();
        }finally{
        	
        }
    	return tableTarget;
    }
    
    public JobInput selectTableDetails(String sequenceID){
	    try{
	    	ResultSet resultSet;
	    	PreparedStatement selectTableDetails = getConnection().prepareStatement(SELECT_QUERY_FOR_SYSTEM_DIM_AGG_TABLE);
	    	selectTableDetails.setString(1,sequenceID );
	    	resultSet = selectTableDetails.executeQuery();
	    
	    	while(resultSet.next()){
	    		jobInput.setSourceTable(setSourceTableDetails(resultSet));
	    		jobInput.setTargetTable(setTargetTableDetails(resultSet));
	    	}
    	} catch(SQLException e){
    	System.out.println("Error message "+e.getMessage());
    	e.printStackTrace();
    }finally{
    	disconnect();
    }
	return jobInput;
   }
    
	 public List<String> selectTableCount(){
		 List<String> sequenceList = new ArrayList<String>();    
		 try{
		    	ResultSet resultSetCount;
		    	PreparedStatement selectCountOfDistinctSequence = getConnection().prepareStatement(SELECT_QUERY_FOR_COUNT_SYSTEM_DIM_AGG_TABLE);
		    	resultSetCount = selectCountOfDistinctSequence.executeQuery();
		    	while(resultSetCount.next()){
		    		sequenceList.add(resultSetCount.getString("SRC_TRG_SEQ_NO"));
		    	}
		    } catch(SQLException e){
		    	System.out.println("Error message "+e.getMessage());
		    	e.printStackTrace();
		    }finally{
		    	disconnect();
		    }
			return sequenceList;
	 }
}
