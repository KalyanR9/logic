package com.bitwise.xml.parser.config;

import java.io.File;
import java.io.FileReader;
import java.util.Properties;

public enum RecordIdentifier {
	ROOT,
	V0,
	V0S3,
	V0S3P1,
	V0S3P2,
	V0S3P3,
	V8S0,
	V8S0P1,
	V8S1,
	V8S1P1,
	V8S2,
	V8S2P1,
	V8S2P2,
	V8S2P3,
	V8S4,
	V8S4P1,
	V8S4P2,
	V8S4P3,
	V8S5,
	V8S5P1,
	V8S6,
	V8S6P1,
	V8S8,
	V8S8P1,
	V8S8P4,
	V8S8P5;
	
	private static final String PATH = "gst.properties";
	private static Properties properties;
	private String value;

	private void init() {
		if (properties == null) {
			properties = new Properties();
			try {
				properties.load(new FileReader(new File(PATH)));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		value = (String) properties.get(this.toString());
		System.out.println("Enum value: " + value);
	}

	public String getValue() {
		if (value == null) {
			init();
		}
		return value;
	}

}
