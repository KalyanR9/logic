package com.bitwise.xml.parser.util;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.stream.Collectors;

import com.bitwise.xml.parser.dto.ColumnDetails;
import com.bitwise.xml.parser.dto.JobInput;
import com.bitwise.xml.parser.dto.Table;

public class GstDemoUtil {
	
	JobInput input= new JobInput();
	
	public static final String KEY = "key";
	public static final String KEY_WITH_NULL_STRING_LENGTH="key_with_null_string_length";
	public static final String COLUMN_LIST = "column_list";
	public static final String KEY_WITH_SQLTYPE_SOURCE= "key_with_sqltype_source";
	public static final String KEY_WITH_SQLTYPE_TARGET= "key_with_sqltype_target";
	public static final String COLUMNS_WITH_SQLTYPE_SOURCE_TABLE = "columns_with_sqltype_source_table";
	public static final String COLUMNS_WITH_SQLTYPE_TARGET_TABLE = "columns_with_sqltype_target_table";
	public static final String COLUMNS_WITH_PRECISION_SOURCE_TABLE = "columns_with_precision_source_table";
	public static final String COLUMNS_WITH_PRECISION_TARGET_TABLE = "columns_with_precision_target_table";
	public static final String COLUMNS_WITH_SCALE_SOURCE_TABLE = "columns_with_scale_source_table";
	public static final String COLUMNS_WITH_SCALE_TARGET_TABLE = "columns_with_scale_target_table";
	public static final String COLUMNS_WITH_DATATYPE_DETAILS_SOURCE_TABLE = "columns_with_datatype_details_source_table";
	public static final String COLUMNS_WITH_DATATYPE_DETAILS_TARGET_TABLE = "columns_with_datatype_details_target_table";
	public static final String COLUMN_REF_COLUMN_TARGET = "column_ref_column_target";
	public static final String SELECT_QUERY_SOURCE_TABLE="sql_select_query_SourceTable";
	public static final String COLUMNS_WITH_SOURCETABLE_INSIDEXML_NONKEY ="columns_with_sourcetable_without_key";//Non Key
	public static final String COLUMNS_WITH_SOURCETABLE_INSIDEXML_KEY ="columns_with_sourcetable_with_key";	//With Key
	public static final String DB_SOURCE_TABLE_SRC="db_source_table_src";
	public static final String DBO_SOURCE_TABLE="sourceTable";
	public static final String DBO_TARGET_TABLE="targetTable";
	public static final String DB_TARGET_TABLE_TRG="db_target_table_trg";
	public static final String VALUE_NONKEY_COLUMNS="value_nonkeycolumns";//VALUE FOR NONKEY
	public static final String DATE_COLUMN_LIST_WITH_DETAILS="date_column_list_with_details";//Date fields
	public static final String COLUMN_LIST_TARGET="columnListTarget";
	public static final String COLUMN_LIST_SOURCE="columnListSource";
	public static final String TARGET_SURROGATE_KEY="targetSurrogateKey";
	public static final String DATE_TYPE_TARGET_COLUMN="dateTypeTargetColumn";
	public static final String DATATYPE_DETAILS_TARGET_TABLE_WITHOUT="datatype_details_target_table_without_shash";
	public static final String DATATYPE_DETAILS_TARGET_NOSURROGATE="datatype_details_target_nosurrogate";
	public static final String COLUMN_LIST_TARGTE_WITHOUT_SURROGATE_KEY ="columnListTargetwithoutSurrogateKey";
	public static final String SOURCE_COLUMN_LIST_NOKEY="source_column_list_nokey";
	public static final String COLUMNS_WITH_SOURCETABLE_NONKEY ="column_with_sourcetable_nonkey";
	public static final String JOB_NAME_OF_GRAPH ="graphName";
	public static Map<String, String> map = new HashMap<String, String>();
	private static final String PATH = "DataTypeMapper.properties";
	private static Properties properties;	
	
	public static void init() {
		if (properties == null) {
			properties = new Properties();
			InputStream input = null;
			try {
				input = GstDemoUtil.class.getClassLoader().getResourceAsStream(PATH);
				properties.load(input);
				map.putAll(properties.entrySet().stream().collect(Collectors.toMap(e -> e.getKey().toString(), e -> e.getValue().toString())));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		for(Map.Entry<String,String> entry : map.entrySet()){
			System.out.println("Key "+ entry.getKey()+" Value "+entry.getValue());
		}	
	}	
 
	public static String buildColumnsRefColumnTarget(Table targetTable) {
		StringBuffer sb = new StringBuffer();
		for(ColumnDetails column : targetTable.getColumns()){
			if(!column.getKey().equalsIgnoreCase("Y") && column.getColumnName() != null){
				if(column.getSurrogateKey() != null && !column.getSurrogateKey().trim().equalsIgnoreCase("Y")){
					System.out.println("Surrogate Key "+column.getSurrogateKey());
					sb.append(column.getColumnName()).append("_ref=").append(column.getColumnName()).append(";").append("\n");
				}
			}
		}
		return sb.toString();
	}

	public static String buildValueNonKeyColumn(List<ColumnDetails> columnDetails){
		StringBuffer sbData= new StringBuffer();
		for(ColumnDetails columns : columnDetails){
			StringBuffer sb= new StringBuffer();
			if(!columns.getKey().equalsIgnoreCase("Y") && columns.getColumnName() != null && columns.getSrcChangeCapture().equalsIgnoreCase("Y")){
				sb.append("-value &apos;");
				sb.append(columns.getColumnName());
				sb.append("&apos;");
				sbData.append(sb.toString()).append("\n");
			}
		}
		return sbData.toString();
	}
	
	public static String buildSourceColumnListNoKey(List<ColumnDetails> columnDetails){
		StringBuffer sb= new StringBuffer();
		for(ColumnDetails columns : columnDetails){
			if(!columns.getKey().equalsIgnoreCase("Y") && columns.getColumnName() != null){
				sb.append("\\(2)0\\(1)\\(3)value\\(2)");
				sb.append(columns.getColumnName());
			}
		}
		return sb.toString();
	}

	public static String buildDateColumnListDetails(List<ColumnDetails> columns){
		StringBuffer sb= new StringBuffer();
		for(ColumnDetails column :columns){
			
			if(column.getSqlType() !=null  && column.getSqlType().trim().equalsIgnoreCase("date")){
				sb.append(column.getColumnName()).append(":nullable string[max=10]=").append(column.getColumnName()).append(";").append("\n");
			}
		}
		return sb.toString();
	}
	
	public static String buildDBSourceTable(String tableName){
		return "db_"+tableName;
	}
	
	public static String buildDBTargetTable(String tableName){
		return "db_"+tableName;
	}
	
	public static String buildColumnsWithSourceTableWithoutKey(Table table){
		StringBuffer sb= new StringBuffer();
		
		for(ColumnDetails columnDetail : table.getColumns()){
			if(!columnDetail.getKey().equalsIgnoreCase("Y") && columnDetail.getColumnName() != null){
				sb.append("![CDATA[");
				sb.append(columnDetail.getColumnName()).append(",").append(columnDetail.getColumnName()).append(",");
				sb.append(table.getTableName());
				sb.append("]]&gt;&lt;/Column&gt;&lt;Column type=\\&apos;string\\&apos;&gt;&lt;");
			}
		}
		System.out.println(" Value of build column "+sb.toString());
		return sb.toString();
	}
	
	public static String buildColumnsWithSourceTableKey(Table table){
		StringBuffer sb= new StringBuffer();
		for(ColumnDetails columnDetail : table.getColumns()){
			if(columnDetail.getKey().equalsIgnoreCase("Y") && columnDetail.getColumnName() != null){
				sb.append("![CDATA[");
				sb.append(columnDetail.getColumnName()).append(",").append(columnDetail.getColumnName()).append(",");
				sb.append(table.getTableName());
				sb.append("]]&gt;&lt;/Column&gt;&lt;");
			}
		}
		return sb.toString();
	}

	public static String buildColumnsWithDatatypesSourceTable(List<ColumnDetails> columns) {
		StringBuilder sbdata = new StringBuilder();
		for (int i =0;i<columns.size();i++) {
			System.out.println("Column List Target "+columns.get(i).getColumnName());
			StringBuilder sb = new StringBuilder();
			if(columns.get(i).getColumnName() != null){	
				sb.append(columns.get(i).getColumnName()).append("\\:");
				sb.append("nullable ");
				sb.append(map.get("DB"+columns.get(i).getSqlType().toUpperCase()));
				if(!columns.get(i).getSqlType().equalsIgnoreCase("date") && !columns.get(i).getSqlType().equalsIgnoreCase("datetime")){
				if(columns.get(i).getPrecision() != null || columns.get(i).getMax() != null){
					sb.append("\\[");
					if(columns.get(i).getMax()!= null){
						sb.append("max\\=");
						sb.append(columns.get(i).getPrecision() != null ? columns.get(i).getPrecision(): columns.get(i).getMax() );
					}else if(columns.get(i).getPrecision() != null){
						sb.append(columns.get(i).getPrecision());
						if(columns.get(i).getScale() != null){
							sb.append("\\,");
							sb.append(columns.get(i).getScale());
						}
					}
					sb.append("\\]\\;");
				}else{
					sb.append("\\;");
				}
			}else{
				sb.append("\\;");
			}
				sbdata.append(sb.toString()).append("\n");
			}	
		}
		System.out.println("value "+sbdata.toString());
		return sbdata.toString();
	}
	
	public static String buildSelectQuerySourceTable(Table sourceTable){
		StringBuffer sb= new StringBuffer();
		sb.append("SELECT ");
		for(ColumnDetails column : sourceTable.getColumns()){
			if(column.getColumnName() != null)
				sb.append(column.getColumnName()).append(",");
		}
		String result = sb.toString();
		if(sb.toString().endsWith(",")){
			result=result.substring(0, result.length() - 1);
		}
		result = result +" FROM dbo."+sourceTable.getTableName();
		return result;
	}
	
	public static String buildColumnsWithDatatypesTargetTable(List<ColumnDetails> columns) {
		StringBuilder sbdata = new StringBuilder();
		for (int i =0;i<columns.size();i++) {
			System.out.println("Column List Target "+columns.get(i).getColumnName());
			StringBuilder sb = new StringBuilder();
			if(columns.get(i).getColumnName() != null){	
				sb.append(columns.get(i).getColumnName()).append("\\:");
				sb.append("nullable ");
				sb.append(map.get("DB"+columns.get(i).getSqlType().toUpperCase()));
				if(!columns.get(i).getSqlType().equalsIgnoreCase("date") && !columns.get(i).getSqlType().equalsIgnoreCase("datetime")){
					System.out.println("Print data type "+columns.get(i).getSqlType());
					if(columns.get(i).getPrecision() != null || columns.get(i).getMax() != null){
						sb.append("\\[");
						if(columns.get(i).getMax()!= null){
							sb.append("max\\=");
							sb.append(columns.get(i).getPrecision() != null ? columns.get(i).getPrecision(): columns.get(i).getMax());
						}else if(columns.get(i).getPrecision() != null){
							sb.append(columns.get(i).getPrecision());
							if(columns.get(i).getScale() != null){
								sb.append("\\,");
								sb.append(columns.get(i).getScale());
							}
						}
						sb.append("\\]\\;");
					}else{
						sb.append("\\;");
					}
				}else{
					sb.append("\\;");
				}
				sbdata.append(sb.toString()).append("\n");
			}
		}
		System.out.println("value "+sbdata.toString());
		return sbdata.toString();
	}
	
	public static String buildColumnsWithDatatypesTargetTableNoSurrogate(List<ColumnDetails> columns) {
		StringBuilder sbdata = new StringBuilder();
		for (int i=0;i<columns.size();i++) {
			System.out.println("Column List Target "+columns.get(i).getColumnName());
			StringBuilder sb = new StringBuilder();
			if(columns.get(i).getColumnName() != null && !columns.get(i).getSurrogateKey().trim().equalsIgnoreCase("Y")){	
				sb.append(columns.get(i).getColumnName()).append(":");
				sb.append("nullable ");
				sb.append(map.get("DB"+columns.get(i).getSqlType().toUpperCase()));
				if(!columns.get(i).getSqlType().equalsIgnoreCase("date") && !columns.get(i).getSqlType().equalsIgnoreCase("datetime")){
					if(columns.get(i).getPrecision() != null || columns.get(i).getMax() != null){
						sb.append("[");
						if(columns.get(i).getMax()!= null){
							sb.append("max=");
							sb.append(columns.get(i).getPrecision() != null ? columns.get(i).getPrecision(): columns.get(i).getMax());
						}else if(columns.get(i).getPrecision() != null){
							sb.append(columns.get(i).getPrecision());
							if(columns.get(i).getScale() != null){
								sb.append(",");
								sb.append(columns.get(i).getScale());
							}
						}
						sb.append("];");
					}else{
						sb.append(";");
					}
				}else{
					sb.append(";");
				}
				sbdata.append(sb.toString());
				if(i != (columns.size()-1))
					sbdata.append("\n");
			}
		}
		System.out.println("value "+sbdata.toString());
		return sbdata.toString();
	}
	
	public static String buildColumnsWithScaleSourceTable(List<ColumnDetails> columns) {
		StringBuilder sb = new StringBuilder();
		for (ColumnDetails columnDetails : columns) {
			if(columnDetails.getScale() != null){
				sb.append(columnDetails.getColumnName()).append("=");
				sb.append(columnDetails.getScale().toUpperCase()).append(", ");
			}
		}	
		String result = sb.toString();
		if (result.endsWith(", ")) {
			result = result.substring(0, result.length() - 2);
		}
		return result;
	}
	
	
	public static String buildColumnsWithScaleTargetTable(List<ColumnDetails> columns) {
		StringBuilder sb = new StringBuilder();
		for (ColumnDetails columnDetails : columns) {
			if(columnDetails.getScale() != null){
				sb.append(columnDetails.getColumnName()).append("=");
				sb.append(columnDetails.getScale().toUpperCase()).append(", ");
			}
		}	
		String result = sb.toString();
		if (result.endsWith(", ")) {
			result = result.substring(0, result.length() - 2);
		}
		return result;
	}

	public static String buildColumnsWithPrecisionSourceTable(List<ColumnDetails> columns) {
		StringBuilder sb = new StringBuilder();
		for (ColumnDetails columnDetails : columns) {
			if(columnDetails.getPrecision() != null){
				sb.append(columnDetails.getColumnName()).append("=");
				sb.append(columnDetails.getPrecision()).append(", ");
			}
		}	
		String result = sb.toString();
		if (result.endsWith(", ")) {
			result = result.substring(0, result.length() - 2);
		}
		return result;
	}
	
	public static String buildColumnsWithPrecisionTargetTable(List<ColumnDetails> columns) {
		StringBuilder sb = new StringBuilder();
		for (ColumnDetails columnDetails : columns) {
			if(columnDetails.getPrecision() != null){
				sb.append(columnDetails.getColumnName()).append("=");
				sb.append(columnDetails.getPrecision()).append(", ");
			}
		}	
		String result = sb.toString();
		if (result.endsWith(", ")) {
			result = result.substring(0, result.length() - 2);
		}
		return result;
	}

	public static String buildColumnsWithSqlTypeSourceTable(List<ColumnDetails> columns) {
		StringBuilder sb = new StringBuilder();
		for (ColumnDetails columnDetails : columns) {
			if(columnDetails.getSqlType()!=null){
				sb.append(columnDetails.getColumnName()).append("=");
				sb.append(map.get(columnDetails.getSqlType().toUpperCase())).append(", ");
			}
		}
		String result = sb.toString();
		if (result.endsWith(", ")) {
			result = result.substring(0, result.length() - 2);
		}
		return result;
	}
	
	
	public static String buildColumnsWithSqlTypeTargetTable(List<ColumnDetails> columns) {
		StringBuilder sb = new StringBuilder();
		for (ColumnDetails columnDetails : columns) {
			if(columnDetails.getSqlType()!= null){
				sb.append(columnDetails.getColumnName()).append("=");
				String value= map.get(columnDetails.getSqlType().toUpperCase());
				System.out.println("value of map object= "+value );
				sb.append(value).append(", ");
			}
		}
		String result = sb.toString();
		if (result.endsWith(", ")) {
			result = result.substring(0, result.length() - 2);
		}
		return result;
	}
	
	

	public static String buildKeyWithSqlTypeSource(ColumnDetails columnDetails) {
		StringBuilder sb = new StringBuilder();
		sb.append(columnDetails.getColumnName()).append("=");
		sb.append(map.get(columnDetails.getSqlType().toUpperCase()));
		return sb.toString();
	}
	
	
	public static String buildKeyWithSqlTypeTarget(ColumnDetails columnDetails) {
		StringBuilder sb = new StringBuilder();
		sb.append(columnDetails.getColumnName()).append("=");
		sb.append(map.get(columnDetails.getSqlType().toUpperCase()));
		return sb.toString();
	}
	
	public static String buildKeyWithNullableSting(ColumnDetails column){
		StringBuffer sb= new StringBuffer(); 
		sb.append(column.getColumnName()).append(":nullable ");
		sb.append(map.get("DB"+column.getSqlType().toUpperCase())).append("[");
		sb.append(column.getPrecision()).append("]");
		
		return sb.toString();
	}

	public static String buildColumnList(List<ColumnDetails> columns) {
		StringBuffer columnList= new StringBuffer();
		for(ColumnDetails columnName :columns){
			if(columnName.getColumnName() != null)
				columnList.append(columnName.getColumnName()).append(",");
		}

		String result = columnList.toString();

		if (result.endsWith(",")) {
			result = result.substring(0, result.length() - 1);
		}
		return result;
	}

	
	public static List<Map<String, Object>> buildColumnListTarget(List<ColumnDetails> columns){
		List<Map<String, Object>> columnsNewData = new ArrayList<Map<String, Object>>(); 
		
		for(ColumnDetails column :columns){
			if(column.getColumnName() != null){
				Map<String, Object> mapData = new HashMap<String, Object>();
				if(!column.getKey().trim().equalsIgnoreCase("Y") && !column.getSurrogateKey().trim().equalsIgnoreCase("Y")){
					mapData.put("columnNameWithReference",column.getColumnName()+"_ref");
				}else{
					mapData.put("columnNameWithReference",column.getColumnName());
				}
				if(!column.getSurrogateKey().trim().equalsIgnoreCase("Y")){
					mapData.put("columnNameLinkSourceRef", "lnk_src_jn."+column.getColumnName());
				}else{
					mapData.put("columnNameLinkSourceRef", "lnk_ref_jn."+column.getColumnName());
				}
				mapData.put("columnName",column.getColumnName());
				mapData.put("sqlType",map.get(column.getSqlType().toUpperCase()));
				mapData.put("precision",column.getPrecision() != null ? column.getPrecision() : "0");
				mapData.put("scale",column.getScale() != null ? column.getScale() : "0");
				mapData.put("key",column.getKey().equalsIgnoreCase("Y") ? "1":"0");
				columnsNewData.add(mapData);
			}
		}
		return columnsNewData;
	}
	
	public static List<Map<String, Object>> buildColumnListSource(List<ColumnDetails> columns){
		List<Map<String, Object>> columnsNewData = new ArrayList<Map<String, Object>>(); 
		
		for(ColumnDetails column :columns){
			if(column.getColumnName() != null){
				Map<String, Object> mapData = new HashMap<String, Object>();
				mapData.put("columnName",column.getColumnName());
				mapData.put("length", column.getMax()!=null?column.getMax():"0");
				mapData.put("sqlType",map.get(column.getSqlType().toUpperCase()));
				mapData.put("sourceType", column.getSqlType().toUpperCase());
				mapData.put("precision",column.getPrecision() != null ? column.getPrecision() : "0");
				mapData.put("scale",column.getScale() != null ? column.getScale() : "0");
				mapData.put("key",column.getKey().equalsIgnoreCase("Y") ? "1":"0");
				if(column.getNullability().equals("YES")){
					mapData.put("isNull", "true");
				}
				else if(column.getNullability().equals("NO")){
					mapData.put("isNull","false");
				}
				mapData.put("pattern", (column.getSqlType().equals("date") || column.getSqlType().equals("datetime"))?"dd-MM-yyyy":"");
				columnsNewData.add(mapData);
			}
		}
		return columnsNewData;
	}
	
	public static List<Map<String, Object>> buildColumnListTargetWithoutSurrogateKey(List<ColumnDetails> columns){
		List<Map<String, Object>> columnsNewData = new ArrayList<Map<String, Object>>(); 
		
		for(ColumnDetails column :columns){
			if(column.getColumnName() != null && !column.getSurrogateKey().trim().equalsIgnoreCase("Y")){
				Map<String, Object> mapData = new HashMap<String, Object>();
				if(!column.getKey().trim().equalsIgnoreCase("Y") && !column.getSurrogateKey().trim().equalsIgnoreCase("Y")){
					mapData.put("columnNameWithReference",column.getColumnName()+"_ref");
				}else{
					mapData.put("columnNameWithReference",column.getColumnName());
				}
				mapData.put("columnName",column.getColumnName());
				mapData.put("sqlType",map.get(column.getSqlType().toUpperCase()));
				mapData.put("precision",column.getPrecision() != null ? column.getPrecision() : "0");
				mapData.put("scale",column.getScale() != null ? column.getScale() : "0");
				mapData.put("key",column.getKey().equalsIgnoreCase("Y") ? "1":"0");
				if(!column.getSqlType().trim().equalsIgnoreCase("date")){
					mapData.put("columnNameDerived","lnk_ccd_tfm."+column.getColumnName());
				}else{
					mapData.put("columnNameDerived","StringToDate(lnk_ccd_tfm."+column.getColumnName()+",&quot;%yyyy-%mm-%dd&quot;)");
				}	
				columnsNewData.add(mapData);
			}
		}
		return columnsNewData;
	}
	
	
	public static String buildTargetSurrogateKey(List<ColumnDetails> columns) {
	String surrogateKey=null;
		
		for(ColumnDetails column : columns){
			if(column.getSurrogateKey().trim().equalsIgnoreCase("Y")){
				surrogateKey=column.getColumnName();
			}
		}
		 return surrogateKey;
	}

	public static String buildDateTypeTargetColumn(List<ColumnDetails> columns) {
		String dateTypeColumnName=null;
		for(ColumnDetails column : columns){
			if(column.getSqlType().trim().equalsIgnoreCase("date")){
				dateTypeColumnName=column.getColumnName();
			}
		}	
		return dateTypeColumnName;
	}

}