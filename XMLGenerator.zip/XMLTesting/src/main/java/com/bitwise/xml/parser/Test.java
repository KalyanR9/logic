package com.bitwise.xml.parser;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;

public class Test {

	private static final String KEY = "{@key}";
	private static final String COLUMN_LIST = "{@column_list}";
	private static final String KEY_WITH_SQLTYPE = "{@key_with_sqltype}";
	private static final String COLUMNS_WITH_SQLTYPE = "{@columns_with_sqltype}";
	private static final String COLUMNS_WITH_PRECISION = "{@columns_with_precision}";
	private static final String COLUMNS_WITH_SCALE = "{@columns_with_scale}";
	private static final String COLUMNS_WITH_DATATYPE_DETAILS = "{@columns_with_datatype_details}";
	private static final String COLUMN_REF_COLUMN = "{@column_ref_column}";

	public static void main(String[] args) throws IOException {
		/*BufferedReader file = new BufferedReader(new FileReader("orch_text.txt"));
		String line;
		StringBuffer inputBuffer = new StringBuffer();

		while ((line = file.readLine()) != null) {

			if (line.contains(KEY)) {
				System.out.println(line);
				line = line.replace(KEY, "1111");

			} else if (line.contains(COLUMN_LIST)) {
				System.out.println(line);
				line = line.replace(COLUMN_LIST, "2222");

			} else if (line.contains(KEY_WITH_SQLTYPE)) {
				System.out.println(line);
				line = line.replace(KEY_WITH_SQLTYPE, "3333");
			} else if (line.contains(COLUMNS_WITH_SQLTYPE)) {
				System.out.println(line);
				line = line.replace(COLUMNS_WITH_SQLTYPE, "4444");

			} else if (line.contains(COLUMNS_WITH_PRECISION)) {
				System.out.println(line);
				line = line.replace(COLUMNS_WITH_PRECISION, "5555");

			} else if (line.contains(COLUMNS_WITH_SCALE)) {
				System.out.println(line);
				line = line.replace(COLUMNS_WITH_SCALE, "6666");

			} else if (line.contains(COLUMNS_WITH_DATATYPE_DETAILS)) {
				System.out.println(line);
				line = line.replace(COLUMNS_WITH_DATATYPE_DETAILS, "7777");

			} else if (line.contains(COLUMN_REF_COLUMN)) {
				System.out.println(line);
				line = line.replace(COLUMN_REF_COLUMN, "8888");

			}
			inputBuffer.append(line);
			inputBuffer.append('\n');
		}
		String inputStr = inputBuffer.toString();

		file.close();

		FileOutputStream fileOut = new FileOutputStream("orch_output.txt");
		fileOut.write(inputStr.getBytes());
		fileOut.close();*/
		
		
		Status[] status = Status.values();
		for (Status st : status) {
			System.out.println(st.getKey());
			System.out.println(st.getValue());
		}
		
	}

}
