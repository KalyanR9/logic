package com.bitwise.xml.parser.dto;

public class JobInput {
	private Table sourceTable;
	private Table targetTable;

	public Table getSourceTable() {
		return sourceTable;
	}

	public void setSourceTable(Table sourceTable) {
		this.sourceTable = sourceTable;
	}

	public Table getTargetTable() {
		return targetTable;
	}

	public void setTargetTable(Table targetTable) {
		this.targetTable = targetTable;
	}

}
