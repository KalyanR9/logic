package com.bitwise.xml.parser.dto;

public class ColumnDetails {
	private String columnName;
	private String sqlType;
	private String precision;
	private String scale;
	private String nullability;
	private String max;
	private String key;
	private String surrogateKey;
	private String srcChangeCapture;
	
	public String getSrcChangeCapture() {
		return srcChangeCapture;
	}
	public void setSrcChangeCapture(String srcChangeCapture) {
		this.srcChangeCapture = srcChangeCapture;
	}
	public String getSurrogateKey() {
		return surrogateKey;
	}
	public void setSurrogateKey(String surrogateKey) {
		this.surrogateKey = surrogateKey;
	}
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public String getMax() {
		return max;
	}
	public void setMax(String max) {
		this.max = max;
	}
	public String getNullability() {
		return nullability;
	}
	public void setNullability(String nullability) {
		this.nullability = nullability;
	}
	public String getColumnName() {
		return columnName;
	}
	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}
	public String getSqlType() {
		return sqlType;
	}
	public void setSqlType(String sqlType) {
		this.sqlType = sqlType;
	}
	public String getPrecision() {
		return precision;
	}
	public void setPrecision(String precision) {
		this.precision = precision;
	}
	public String getScale() {
		return scale;
	}
	public void setScale(String scale) {
		this.scale = scale;
	}

}
