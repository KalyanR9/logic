package com.bitwise.xml.parser.dto;

import java.util.List;

public class Table {
	private String tableName;
	private ColumnDetails keyColumn;
	private List<ColumnDetails> columns;

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	public ColumnDetails getKeyColumn() {
		return keyColumn;
	}

	public void setKeyColumn(ColumnDetails keyColumn) {
		this.keyColumn = keyColumn;
	}

	public List<ColumnDetails> getColumns() {
		return columns;
	}

	public void setColumns(List<ColumnDetails> columns) {
		this.columns = columns;
	}
}
