package com.bitwise.xml.parser;

import java.io.File;
import java.io.FileOutputStream;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import com.bitwise.jaxb.DSExport;
import com.bitwise.jaxb.JobType;

public class Demo {

	public static void main(String[] args) throws Exception {
		JAXBContext jc = JAXBContext.newInstance("com.bitwise.jaxb");

		Unmarshaller unmarshaller = jc.createUnmarshaller();
		DSExport bookingElement = (DSExport) unmarshaller.unmarshal(new File("SCD_TEST_BKP.xml"));

		// DSExport dsExport = bookingElement.getValue();

		for (JAXBElement<?> element : bookingElement.getHeaderOrJobOrSharedContainer()) {

			if (element.getValue() instanceof JobType) {
				JobType jobType = (JobType) element.getValue();
				System.out.println(jobType.getIdentifier());
				jobType.setIdentifier("SCD_TEST_BKP_1");

			}

		}

		FileOutputStream output = new FileOutputStream(new File("done_o.xml"));
		Marshaller marshaller = jc.createMarshaller();
		marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		marshaller.marshal(bookingElement, output);

	}

}
