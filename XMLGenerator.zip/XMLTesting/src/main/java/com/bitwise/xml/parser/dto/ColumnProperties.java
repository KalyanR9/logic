package com.bitwise.xml.parser.dto;

public enum ColumnProperties {
	
	NAME("Name", null),
	SQL_TYPE("SqlType", null),
	PRECISION("Precision", null),
	SCALE("Scale", null),
	NULLABLE("Nullable", "1"),
	KEY_POSITION("KeyPosition", "0"),
	DISPLAY_SIZE("DisplaySize", "0"),
	DERIVATION("Derivation", "lnk_db_ref_cp.ADJ_ID"),
	GROUP("Group", "0"),
	PARSED_DERIVATION("ParsedDerivation", "lnk_db_ref_cp.ADJ_ID"),
	SOURCE_COLUMN("SourceColumn", "lnk_db_ref_cp.ADJ_ID"),
	SORT_KEY("SortKey", "0"),
	SORT_TYPE("SortType", "0"),
	ALLOW_CRLF("AllowCRLF", "0"),
	LEVEL_NO("LevelNo", "0"),
	OCCURS("Occurs", "0"),
	PADN_ULLS("PadNulls", "0"),
	SIGN_OPTION("SignOption", "0"),
	SORTING_ORDER("SortingOrder", "0"),
	ARRAY_HANDLING("ArrayHandling", "0"),
	SYNCI_NDICATOR("SyncIndicator", "0"),
	PAD_CHAR("PadChar", null),
	EXTENDED_PRECISION("ExtendedPrecision", "0"),
	TAGGED_SUBREC("TaggedSubrec", "0"),
	OCCURS_VARYING("OccursVarying", "0"),
	PKEY_IS_CASELESS("PKeyIsCaseless", "0"),
	SCD_PURPOSE("SCDPurpose", "0");
	
	private final String key;
	private final String value;

	ColumnProperties(String key, String value) {
		this.key = key;
		this.value = value;
	}

	public String getKey() {
		return key;
	}

	public String getValue() {
		return value;
	}

}
