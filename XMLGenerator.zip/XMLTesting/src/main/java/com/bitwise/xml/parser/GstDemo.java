package com.bitwise.xml.parser;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.exception.MethodInvocationException;
import org.apache.velocity.exception.ParseErrorException;
import org.apache.velocity.exception.ResourceNotFoundException;
import org.apache.velocity.runtime.RuntimeConstants;
import org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader;

import com.bitwise.dao.GstDemoDBConnection;
import com.bitwise.xml.parser.dto.JobInput;
import com.bitwise.xml.parser.util.GstDemoUtil;

public class GstDemo {
	private static final String VELOCITY_TEMPALTE = "talend_temp.vm";
	private static final String SRC_COLUMN_LIST = "src_column_list";
	private static final String TARGET_COLUMN_LIST = "target_column_list";
	private static final String TYPE0_CHANGES_SOURCE_LIST = "type0_changes_source_List";
	private static final String TYPE2_CHANGES_SOURCE_LIST = "type2_changes_source_List";
	private static final String SAMPLE_QUOTES = "quotes1";
	private static final String COMMON_COLUMN_LIST = "common_column_list";
	private static final String TRGDATE_COLUMN_LIST = "trgDate_column_list";
	private static final String COLUMN_NAME = "columnName";

	static BufferedWriter bufferWriter = null;

	public static void main(String[] args) throws Exception {
		VelocityEngine velocityEngine = new VelocityEngine();
		velocityEngine.setProperty(RuntimeConstants.RESOURCE_LOADER, "classpath");
		velocityEngine.setProperty("classpath.resource.loader.class", ClasspathResourceLoader.class.getName());

		velocityEngine.init();
		Template template = velocityEngine.getTemplate(VELOCITY_TEMPALTE);
		VelocityContext velocityContext = new VelocityContext();
		
			GstDemoUtil.init();

			GstDemoDBConnection gstDemoDBConnection = new GstDemoDBConnection();
			List<String> sequenceList = gstDemoDBConnection.selectTableCount();
			GstDemoDBConnection gstDemoDBConnectionNew = new GstDemoDBConnection();
			
			for (int i = 0; i < sequenceList.size(); i++) {
				JobInput input = gstDemoDBConnectionNew.selectTableDetails(sequenceList.get(i));

				String target_surrogate_key = GstDemoUtil.buildTargetSurrogateKey(input.getTargetTable().getColumns());
				velocityContext.put(GstDemoUtil.TARGET_SURROGATE_KEY, target_surrogate_key);

				String key = input.getSourceTable().getKeyColumn().getColumnName();
				velocityContext.put(GstDemoUtil.KEY, key);

				List<Map<String, Object>> column_List_Source = GstDemoUtil
						.buildColumnListSource(input.getSourceTable().getColumns());
				List<Map<String, Object>> target_column_List = GstDemoUtil
						.buildColumnListSource(input.getTargetTable().getColumns());

				String source_Table = input.getSourceTable().getTableName();
				String target_Table = input.getTargetTable().getTableName();
				velocityContext.put(GstDemoUtil.DBO_SOURCE_TABLE, source_Table);
				velocityContext.put(GstDemoUtil.DBO_TARGET_TABLE, target_Table);

				velocityContext.put(SRC_COLUMN_LIST, column_List_Source);
				velocityContext.put(TARGET_COLUMN_LIST, target_column_List);

				List<String> sourceColumnNameList = new ArrayList<String>();
				input.getSourceTable().getColumns().stream().forEach(column -> {
					if (column.getColumnName() != null) {
						sourceColumnNameList.add(column.getColumnName());
					}
				});

				List<Map<String, Object>> common_column_list = new ArrayList<Map<String, Object>>();
				column_List_Source.stream().forEach(targetColumn -> {
					if (targetColumn.get(COLUMN_NAME) != null) {
						sourceColumnNameList.stream().forEach(columnName -> {
							if (columnName.equalsIgnoreCase(targetColumn.get(COLUMN_NAME).toString())) {
								common_column_list.add(targetColumn);
							}
						});
					}
				});

				List<Map<String, Object>> trgDate_column_list = new ArrayList<Map<String, Object>>();
				target_column_List.stream().forEach(column -> {
					if (column.get("pattern").toString().equals("dd-MM-yyyy")) {
						trgDate_column_list.add(column);
					}
				});

				List<String> type2_List = new ArrayList<String>();
				List<String> type0_List = new ArrayList<String>();
				input.getSourceTable().getColumns().stream().forEach(column -> {
					if (column.getSrcChangeCapture() != null && column.getColumnName() != null
							&& column.getKey().equalsIgnoreCase("N")) {
						if (column.getSrcChangeCapture().equals("Y")) {
							type2_List.add(column.getColumnName());
						} else if (column.getSrcChangeCapture().equals("N")) {
							type0_List.add(column.getColumnName());
						}
					}
				});

				velocityContext.put(TYPE0_CHANGES_SOURCE_LIST, type0_List);
				velocityContext.put(TYPE2_CHANGES_SOURCE_LIST, type2_List);
				velocityContext.put(TRGDATE_COLUMN_LIST, trgDate_column_list);
				velocityContext.put(COMMON_COLUMN_LIST, common_column_list);
				velocityContext.put(SAMPLE_QUOTES,
						",&#xA;&#x9;&#x9;\\&quot;&quot;+context.mssql_powerbi_Schema+&quot;\\&quot;");

				String output = "talend_output" + (i+1) + ".xml";
				StringWriter stringWriter = new StringWriter();
				try {
					bufferWriter = new BufferedWriter(new FileWriter(new File(output), true));
					template.merge(velocityContext, stringWriter);
					bufferWriter.write(stringWriter.toString());
					bufferWriter.flush();
				} catch (IOException | ResourceNotFoundException|ParseErrorException|MethodInvocationException e) {
					e.printStackTrace();
				}
				finally {
					bufferWriter.close();
				}
				System.out.println(output + " File generated Succesfully!!");
		}
	}
}
